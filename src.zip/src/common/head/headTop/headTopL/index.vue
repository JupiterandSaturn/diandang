<template>
  <div class="headLeft">
		<div class="login">
			<a href="#">登录</a>
		</div>
		<div class="about">
			<a href="#">关于我们</a>
		</div>
	</div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss">
	.contentTop>.headLeft{
		display:flex;
		justify-content: center;
	}

	.login{
		font-size:10px;
		margin-left:50px;
	}
	.about{
		font-size:10px;
		margin-left:56px;
	}
</style>
