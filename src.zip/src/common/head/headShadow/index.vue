<template>
	<div id="headShadow">
		
	</div>
</template>

<script>

</script>

<style scoped>
	#headShadow{
		width:100%;
		height:14px;
		background:#444;
		opacity:0.2
	}
</style>
