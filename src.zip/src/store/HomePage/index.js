import bus from '@/bus'
export default({
    state:{

    },
    mutations:{

    },
    actions:{
        // getIndex(){

        
    }
})