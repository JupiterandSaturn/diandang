<template>
    <div class='rg_btm'>
        <div class='one'>
            <p>免费配送</p>
        </div>
        <div class='two'>
            <p>需要帮助？</p>
        </div>
        <div class='three'>
            <p>退款方式</p>
        </div>
        <div class='four'>
            <p>退换货政策</p>
        </div>
        <div class='five'>
            <p>取件方式</p>
        </div>
   </div>
</template>
<script>
export default {
    name:'bottom',
            }
</script>
<style scope>
.rg_btm .one{
                          width:399px;
                          height:67px;
                          border-bottom:1px solid rgba(200,200,200,1);
                          opacity:1;
                        }
.rg_btm .one p{
                            width:56px;
                            height:19px;
                            font-size:14px;
                            font-family:Microsoft YaHei;
                            font-weight:400;
                            line-height:19px;
                            color:rgba(27,27,27,1);
                            opacity:1;
                            margin-left:187px;
                            line-height: 67px;
                            text-align: center;
                          }                       
.rg_btm .two{
                          width:399px;
                          height:68px;
                          border-bottom:1px solid rgba(200,200,200,1);
                          opacity:1;
                         }  
.rg_btm .two p{
                            font-size:14px;
                            font-family:Microsoft YaHei;
                            font-weight:400;
                            line-height:19px;
                            color:rgba(135,135,135,1);
                            opacity:1;
                            margin-left:57px;
                            padding-top:24px;
                          }                                              
.rg_btm .three{
                          width:399px;
                          height:64px;
                          border-bottom:1px solid rgba(200,200,200,1);
                          opacity:1;
                          } 
.rg_btm .three p{
                            font-size:14px;
                            font-family:Microsoft YaHei;
                            font-weight:400;
                            line-height:19px;
                            color:rgba(135,135,135,1);
                            opacity:1;
                            margin-left:57px;
                            padding-top:22px;
                          } 
.rg_btm .four{
                          width:399px;
                          height:68px;
                          border-bottom:1px solid rgba(200,200,200,1);
                          opacity:1;
                         } 
.rg_btm .four p{
                          font-size:14px;
                          font-family:Microsoft YaHei;
                          font-weight:400;
                          line-height:19px;
                          color:rgba(135,135,135,1);
                          opacity:1;
                          margin-left:57px;
                          padding-top:25px;
                        }                          
.rg_btm .five{
                          width:399px;
                          height:66px;
                          border-bottom:1px solid rgba(200,200,200,1);
                          opacity:1;
                          } 
.rg_btm .five p{
                            font-size:14px;
                            font-family:Microsoft YaHei;
                            font-weight:400;
                            line-height:19px;
                            color:rgba(135,135,135,1);
                            opacity:1;
                            margin-left:57px;
                            padding-top:24px;
                          }                          

</style>
