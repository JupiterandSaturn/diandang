<template>
    <div>
        <hhh></hhh>
        <mmm></mmm>
        <fff></fff>
    </div>
</template>
<script>
import hhh from './third_0/hhh.vue'
import mmm from './third_1/mmm.vue'
import fff from './third_2/fff.vue'

export default {
                components:{
                    hhh,
                    mmm,
                    fff
                }
}
</script>
<style>
*{
    margin: 0 ;
    padding: 0;
}

a{
    text-decoration: none;
}
li{
    list-style: none;
}
img{
    display: inline-block;
}
</style>
