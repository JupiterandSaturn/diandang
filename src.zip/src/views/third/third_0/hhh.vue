<template>
    <div id="third-nav">
        <ul>
            <li>
                <a href="#">类别 <img src="../../../../public/images/imgPersonal/down.png" alt=""></a>
                <span></span>
                <a href="#">品牌 <img src="../../../../public/images/imgPersonal/down.png" alt=""></a>
            </li>
        </ul>
    </div>
</template>
<script>
export default {
    
}
</script>
<style>
    
</style>
