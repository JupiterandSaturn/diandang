<template>
     <div id="logo-info-more">
            <input type="button" value="加载更多">
    </div> 
</template>
<script>
export default {
    
}
</script>
<style>

#logo-info-more{
    text-align: center;
    background: #E7E7E7;
    height:110px;
    line-height: 110px;
}
#logo-info-more input{
    width: 187px;
    height: 49px;
    background: #000000;
    border: none;
    font-size: 14px;
    color: #E5DFD9;
}

</style>
