<template>
       <div id="goods-list">
        <ul>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p>123213</p>
                <p>12123</p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
            <li>
                <img src="../../../../public/images/imgPersonal/sy.png" alt="">
                <p></p>
                <p></p>
            </li>
        </ul>
       </div>
</template>
<script>
export default {
    
}
</script>

<style scope>
#goods-list{
    width: 1870px;
    margin: 0 auto;
    overflow: hidden;
}
#goods-list ul{

    overflow: hidden;
    margin-top: 7px;

}
#goods-list ul li{
    float: left;
    width: 25%;
    height: 574px;
    text-align: center;

    background: #E7E7E7;
    border-bottom: 1px solid white;
    border-right: 1px solid white;
    box-sizing: border-box;
    overflow: hidden;

}

#goods-list ul li span{
    display: inline-block;
    width: 0px;
    height: 100%;
    vertical-align: middle;
}
#goods-list ul li img{
    width: 166px;
    /*height: 150px;*/
    display: inline-block;
    vertical-align: middle;

}
</style>
