<template>
  <div class="first">
    <div class="content">
      <p>In a ghetto where trafficking and religion run side by side, Dounia is eager for power and success. Supported by Maimouna, her best friend, she decides to follow in the footsteps of Rebecca, a respected dealer. But when Dounia meets Djigui, a young se nsuous dancer, her daily life is disrupted.</p>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
    .first{
        width:100%;
        height:395px;/*563px*/
        background-image:url(../../../../../public/images/imgAboutUs/backL1.png);
        background-repeat: no-repeat;
		background-size:100% 100%;
    }
    .first>.content{
        width:50%;
        height:100%;
        background:#fff;
        float: right;
        text-align: center;
        display: flex;
        align-items: center;
    }
    p{
        font-size:12px;
        color:#4B4B4B;
        line-height:40px;
        
    }
</style>
