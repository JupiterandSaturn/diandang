<template>
   <div class='sec'>
       <img class='sec_1' src='../../../../public/images/imgPersonal/11.png'>
       <img class='sec_2'>
       <img class='sec_3' src='../../../../public/images/imgPersonal/11.png'>
   </div>
</template>

<script>
export default {
    
}
</script>

 <style scope>
 .sec{
      width:1366px;
      height:865px;
      position:relative;
      margin-bottom:80px;
      }
  .sec .sec_1{
                width:409px;
                height:706px;
                background:rgba(27,27,27,1);
                opacity:0.53;
                
                float:left;
             } 
   .sec .sec_2{
                width:957px;
                height:865px;
                background:black;
                /* position:relative; */
                float:right;
                 } 
    .sec .sec_3{
               width:859px;
               height:534px; 
               display:inline-block;
               position:absolute; 
               z-index:1;
               margin-left:-157px;
               margin-top:82px 
                }           
 </style>