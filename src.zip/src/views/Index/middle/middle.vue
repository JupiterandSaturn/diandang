<template>
   <div class='middle'>
       <div class='one'>
          <img src='../../../../public/images/imgPersonal/sy.png'>
          <span>手机典当</span>
       </div>
        
       <div class='two'>
          <img src='../../../../public/images/imgPersonal/pb.png'>
          <span>手机典当</span>
       </div>
        
       <div class='three'>
           <img src='../../../../public/images/imgPersonal/sj.png'>
           <span>手机典当</span>
       </div>
   
       <div class='four'>
          <img src='../../../../public/images/imgPersonal/sm.png'>
          <span>手机典当</span>
       </div>
             
       <div class='five'>
          <img src='../../../../public/images/imgPersonal/sy.png'>
          <span>手机典当</span>
       </div>
      
   </div> 
</template>
<script>
export default {
    
}
</script>
<style scope>
.middle{
        width:1330px;
        height:652px;
        background:rgba(231,231,231,1);
        opacity:1;
        position: relative;
        margin:0 auto;
        margin-top:134px;
       }
.middle .one{
              width:275px;
              height:202px;
              margin-left:198px;
              margin-top:58px;
              position:absolute;
           }
.middle .one img{
                    width:275px;
                    height:164px;               
                    border:1px dotted grey;
                    }
.middle .one span{
                  padding-top:12px;
                  margin:0 auto;
                  }                    
.middle .two{
              width:275px;
              height:223px;
              margin-left:198px;
              margin-top:383px;
              position:absolute;
            }                    
.middle .two img{
              width:275px;
              height:164px;
              border:1px dotted grey;
             } 
.middle .two span{
                  padding-top:33px;
                  margin:0 auto;
                  }    
.middle .three{
               width:276px;
              height:548px;
              margin-left:527px;
              margin-top:58px;
              position:absolute;
             }
.middle .three img{
              width:276px;
              height:489px;
             border:1px dotted grey;

             }
.middle .three span{
                  padding-top:33px;
                  margin:0 auto;
                  }
.middle .four{
              width:275px;
              height:202px;
              margin-left:857px;
              margin-top:58px;
              position:absolute;
}            
.middle .four img{
              width:275px;
              height:164px;
              border:1px dotted grey;
             }
.middle .four span{
                  padding-top:12px;
                  margin:0 auto;
                  }
.middle .five{
              width:275px;
              height:223px;
               margin-left:857px;
              margin-top:383px;
              position:absolute;
}
.middle .five img{
              width:275px;
              height:164px;
              border:1px dotted grey;
             }
.middle .five span{
                  padding-top:33px;
                  margin:0 auto;
                  }
.middle span{
                display: block;
                width:80px;
                height:26px;
                font-size:20px;
                font-weight:400;
                line-height:26px;
                color:rgba(27,27,27,1);
                opacity:1;
                } 


</style>
