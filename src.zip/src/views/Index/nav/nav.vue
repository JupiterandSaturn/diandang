<template>
    <div class='nav'>
       <h3>品牌故事</h3>
       <div class='bor'></div>
       <div>
           <div class='left'>
              <div class='lt_1'>
                 <p>dream</p>
                 <p>love</p>
              </div>
              <div class='lt_2'>
                 <p>success</p>
                 <p>smile</p>
              </div>
              <div class='lt_3'>
                 <p>luck</p>
                 <p>workhard</p>
              </div>
           </div>
           <div class='right'>
              <p>That you use your mother's pulse and I tell My country and I like the sea, 
                 and spray a Wave is the sea of the newborn baby sea wave that rely on 
                 Whenever the sea I was laughing at the vortex of a smile  
                 I shared with the sea of sadness about it to share the joy of the sea 
              </p>
           </div>
       </div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style less='' scope>
   .nav{
            width:1330px;
            height:675px;
            margin:0 auto;
            }  
    .nav h3{
               width:136px;
               height:45px;
               font-size:34px;
               font-family:Microsoft YaHei;
               font-weight:400;
               line-height:45px;
               color:rgba(27,27,27,1);
               opacity:1;
               margin:0 auto;
               padding-top:95px;
    }
    .nav .bor{
               width:162px;
               height:0px;
               border-bottom:1px solid rgba(112,112,112,1);
               opacity:1;
               padding-top:30px;
               margin:0 auto;
                  }
    .nav .left{
               float:left;
               width:510px;
               height: 142px;
               margin-left:79px;
               margin-top:232px;
    }
    .nav .left p{
                  font-size:14px;
                  font-family:Microsoft YaHei;
                  font-weight:400;
                  line-height:19px;
                  color:rgba(135,135,135,1);
                  opacity:1;
                }
   .nav .left .lt_1{
                     display:inline-block;
                     margin-top:2px;
                     /* margin-left:79px; */
                    }
   .nav .left .lt_2{
                    display:inline-block;
                     margin-top:2px;
                     margin-left:112px;
                    } 
   .nav .left .lt_3{
                     margin-top:27px;
                    }                                
    .nav .right{
                float:right;
                width:602px;
                height:139px;
                margin-right:139px;
                margin-top:232px;
              }
   .nav .right p{
                  font-size:14px;
                  font-weight:400;
                  line-height:40px;
                  color:rgba(135,135,135,1);
                  opacity:1;
                  margin-top:-12px;
                  }
</style>

