<template>
        <div class="head_bottom">
            <ul>
                 <li><a href="#" class="bt_1">手机回收</a></li>
                 <li><a href="#" class="bt_2">平板电脑回收</a></li>
                 <li><a href="#" class="bt_3">笔记本回收</a></li>
                 <li><a href="#" class="bt_4">摄影摄像回收</a></li>
                 <li><a href="#" class="bt_5">智能数码回收</a></li>
             </ul> 
        </div> 
</template>
<script>
import popover from './head/popover/index.vue'

export default {
 
    components:{
        popover,
    }
}
</script>
<style>

</style>
