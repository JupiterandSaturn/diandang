<template>
    <div>
       
       <Central/>
       
    </div>
</template>

<script>
import Central from './central'

export default {
                components:{
                
                    Central
                        }
}
</script>

<style scope>
*{
    margin:0;
    padding:0
}
ul,ol li{
       text-decoration: none;
       list-style: none;
       float: left;
}
a{
    text-decoration: none;
}
body{
     width: 100%;
    }
</style>

